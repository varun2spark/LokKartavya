const politicians = [
  { 
    id: '1', 
    name: 'Narendra Modi', 
    role: 'Prime Minister / MP', 
    constituency: 'Varanasi', 
    term: '2024 - 2029', 
    education: 'M.A. Political Science (Gujarat University)', 
    professionalHistory: 'Chief Minister of Gujarat (2001-2014), BJP General Secretary',
    keyResponsibilities: 'Head of Government, Ministry of Personnel, Department of Atomic Energy, Space',
    image: 'https://ui-avatars.com/api/?name=Narendra+Modi&background=f97316&color=fff&size=200&bold=true',
    criminalCases: 0,
    budget: { 
      total: '₹5,000 Cr', 
      utilized: '₹3,420 Cr', 
      categories: [
        { name: 'Infrastructure', amount: '₹2,000 Cr', percentage: 40, color: '#3B82F6' },
        { name: 'Urban Development', amount: '₹900 Cr', percentage: 18, color: '#10B981' },
        { name: 'Healthcare', amount: '₹520 Cr', percentage: 10, color: '#EF4444' }
      ]
    },
    commitments: [
      { id: 101, title: 'Clean Ganga Project Phase 3', status: 'in-progress' },
      { id: 102, title: '100% Electrification of Rural Varanasi', status: 'completed' },
      { id: 103, title: 'New Multi-Speciality AIIMS', status: 'pending' }
    ],
    issues: [
      { id: 201, title: 'Traffic congestion near Dashashwamedh Ghat', date: '2023-11-12' },
      { id: 202, title: 'Water-logging in low lying areas during monsoon', date: '2023-08-04' }
    ]
  },
  { 
    id: '2', 
    name: 'Rahul Gandhi', 
    role: 'Leader of Opposition / MP', 
    constituency: 'Raebareli', 
    term: '2024 - 2029', 
    education: 'M.Phil (Trinity College, Cambridge)', 
    professionalHistory: 'President of INC (2017-2019), MP from Amethi (2004-2019)',
    keyResponsibilities: 'Leader of Opposition in Lok Sabha, Parliamentary Standing Committees',
    image: 'https://ui-avatars.com/api/?name=Rahul+Gandhi&background=0ea5e9&color=fff&size=200&bold=true',
    criminalCases: 19,
    budget: { 
      total: '₹25.0 Cr', 
      utilized: '₹14.0 Cr', 
      categories: [
        { name: 'Infrastructure', amount: '₹5.5 Cr', percentage: 22, color: '#3B82F6' },
        { name: 'Education', amount: '₹4.5 Cr', percentage: 18, color: '#F59E0B' },
        { name: 'Women Empowerment', amount: '₹4.0 Cr', percentage: 16, color: '#8B5CF6' }
      ]
    },
    commitments: [
      { id: 104, title: 'Establish 5 New ITIs for Youth', status: 'pending' },
      { id: 105, title: 'Provide setup capital for Women SHGs', status: 'in-progress' },
      { id: 106, title: 'Upgrade Block-level Hospitals', status: 'completed' }
    ],
    issues: [
      { id: 203, title: 'Pending scholarships for college students', date: '2024-01-15' }
    ]
  },
  { 
    id: '3', 
    name: 'Arvind Kejriwal', 
    role: 'MLA', 
    constituency: 'New Delhi', 
    term: '2020 - 2025', 
    education: 'B.Tech Mechanical Engineering (IIT Kharagpur)', 
    professionalHistory: 'Joint Commissioner of Income Tax (IRS), Right to Information Activist',
    keyResponsibilities: 'Chief Minister of Delhi, Chairman of NDMC, Policy oversight',
    image: 'https://ui-avatars.com/api/?name=Arvind+Kejriwal&background=3b82f6&color=fff&size=200&bold=true',
    criminalCases: 10,
    budget: { 
      total: '₹120.0 Cr', 
      utilized: '₹95.0 Cr', 
      categories: [
        { name: 'Healthcare', amount: '₹45.0 Cr', percentage: 37, color: '#EF4444' },
        { name: 'Education', amount: '₹35.0 Cr', percentage: 29, color: '#F59E0B' },
        { name: 'Public Welfare', amount: '₹15.0 Cr', percentage: 12, color: '#10B981' }
      ]
    },
    commitments: [
      { id: 107, title: '100 New Mohalla Clinics', status: 'completed' },
      { id: 108, title: 'Cleaning Yamuna River', status: 'in-progress' },
      { id: 109, title: 'Free Wi-Fi across constituency', status: 'completed' }
    ],
    issues: [
      { id: 204, title: 'Air pollution levels extremely high in winters', date: '2023-12-01' },
      { id: 205, title: 'Irregular water supply in some pockets', date: '2024-02-18' }
    ]
  },
  { 
    id: '4', 
    name: 'Amit Shah', 
    role: 'Home Minister / MP', 
    constituency: 'Gandhinagar', 
    term: '2024 - 2029', 
    education: 'B.Sc. Biochemistry (CU Shah Science College)', 
    professionalHistory: 'President of BJP (2014-2020), Home Minister of Gujarat (2003-2010)',
    keyResponsibilities: 'Minister of Home Affairs, Minister of Cooperation, Internal Security',
    image: 'https://ui-avatars.com/api/?name=Amit+Shah&background=f97316&color=fff&size=200&bold=true',
    criminalCases: 4,
    budget: { 
      total: '₹1,200 Cr', 
      utilized: '₹840 Cr', 
      categories: [
        { name: 'National Security', amount: '₹600 Cr', percentage: 50, color: '#6B7280' },
        { name: 'Infrastructure', amount: '₹150 Cr', percentage: 12, color: '#3B82F6' },
        { name: 'Cyber Security', amount: '₹90 Cr', percentage: 7, color: '#6366F1' }
      ]
    },
    commitments: [
      { id: 110, title: 'Smart City Command Center Integration', status: 'completed' },
      { id: 111, title: 'GIFT City Expansion Phase 2', status: 'in-progress' }
    ],
    issues: [
      { id: 206, title: 'Housing affordability in new development zones', date: '2023-10-22' }
    ]
  },
  { 
    id: '5', 
    name: 'Mamata Banerjee', 
    role: 'Chief Minister / MLA', 
    constituency: 'Bhabanipur', 
    term: '2021 - 2026', 
    education: 'L.L.B (Jogesh Chandra Chaudhuri Law College), M.A.', 
    professionalHistory: 'Minister of Railways (Govt of India), Minister of Coal, Sports',
    keyResponsibilities: 'Chief Minister of West Bengal, Minister of Home & Hill Affairs',
    image: 'https://ui-avatars.com/api/?name=Mamata+Banerjee&background=10b981&color=fff&size=200&bold=true',
    criminalCases: 5,
    budget: { 
      total: '₹450.0 Cr', 
      utilized: '₹310.0 Cr', 
      categories: [
        { name: 'Public Welfare', amount: '₹150 Cr', percentage: 33, color: '#10B981' },
        { name: 'Infrastructure', amount: '₹90.0 Cr', percentage: 20, color: '#3B82F6' },
        { name: 'Healthcare', amount: '₹70.0 Cr', percentage: 15, color: '#EF4444' }
      ]
    },
    commitments: [
      { id: 112, title: 'Increase allowance for Lakshmir Bhandar', status: 'completed' },
      { id: 113, title: 'Bhabanipur underground drainage overhaul', status: 'in-progress' }
    ],
    issues: [
      { id: 207, title: 'Hawker encroachment on main roads', date: '2024-03-05' }
    ]
  },
  { 
    id: '6', 
    name: 'Akhilesh Yadav', 
    role: 'MP', 
    constituency: 'Kannauj', 
    term: '2024 - 2029', 
    education: 'M.E. Environmental Eng. (University of Sydney)', 
    professionalHistory: 'Chief Minister of Uttar Pradesh (2012-2017)',
    keyResponsibilities: 'MP from Kannauj, National President of Samajwadi Party',
    image: 'https://ui-avatars.com/api/?name=Akhilesh+Yadav&background=ef4444&color=fff&size=200&bold=true',
    criminalCases: 3,
    budget: { 
      total: '₹30.0 Cr', 
      utilized: '₹12.0 Cr', 
      categories: [
        { name: 'Agriculture', amount: '₹6.0 Cr', percentage: 20, color: '#059669' },
        { name: 'Youth Employment', amount: '₹4.0 Cr', percentage: 13, color: '#F59E0B' },
        { name: 'Sports Infrastructure', amount: '₹2.0 Cr', percentage: 6, color: '#3B82F6' }
      ]
    },
    commitments: [
      { id: 114, title: 'Perfume Park Development', status: 'in-progress' },
      { id: 115, title: 'Cold storage subsidy for potato farmers', status: 'pending' }
    ],
    issues: [
      { id: 208, title: 'Crop damage compensation delay', date: '2024-01-28' }
    ]
  }
];

// Simple auth check
function checkAuth() {
    const isLoggedIn = localStorage.getItem('lokkartavya_loggedIn');
    if (!isLoggedIn && !window.location.pathname.endsWith('login.html') && !window.location.pathname.endsWith('register.html')) {
        window.location.href = 'login.html';
    }
}

// Function to handle logout
function logout() {
    localStorage.removeItem('lokkartavya_loggedIn');
    window.location.href = 'login.html';
}

// Add event listener to handle basic logic on load
document.addEventListener('DOMContentLoaded', () => {
    checkAuth();
});
