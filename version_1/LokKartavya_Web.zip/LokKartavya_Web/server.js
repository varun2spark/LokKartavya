const express = require('express');
const path = require('path');

const app = express();
const PORT = 3000;

// Serve all static files (like CSS, JS, Images) from the current folder
app.use(express.static(__dirname));

// Serve index.html when people go to the root URL (/)
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

// Start the server
app.listen(PORT, () => {
    console.log(`Server is running! Click to view: http://localhost:${PORT}`);
});
